# -*- coding: utf8 -*-
"""
考研决策包 - 认证云函数
腾讯云 SCF (Serverless Cloud Function) + Function URL 触发

环境变量:
  MASTER_KEY     - base64编码的32字节主密钥（仅用于内部，不返回前端）
  ADMIN_TOKEN    - 管理鉴权令牌（仅master登录时返回，用于管理操作）
  ACCOUNTS_JSON  - JSON字符串，账号列表（含密码哈希）
  SECRET_SEED    - 密钥种子（用于动态生成每日密钥）
  ALLOWED_ORIGIN - 允许的前端域名（CORS）
  GITHUB_TOKEN   - GitHub PAT（读写state.json）
  GITHUB_REPO    - GitHub仓库地址（如 owner/repo）

状态持久化: 通过 GitHub API 读写 state.json，实现试用激活和账号停用的持久化
每日密钥: 动态生成，无需维护daily_keys.json
"""

import json
import hashlib
import hmac
import os
import time
import base64
import secrets
from datetime import datetime, timezone, timedelta
from urllib import request, error

# ===== 从环境变量读取配置 =====
MASTER_KEY = os.environ.get('MASTER_KEY', '')
ADMIN_TOKEN = os.environ.get('ADMIN_TOKEN', '')
ACCOUNTS_JSON = os.environ.get('ACCOUNTS_JSON', '[]')
SECRET_SEED = os.environ.get('SECRET_SEED', '')
ALLOWED_ORIGIN = os.environ.get('ALLOWED_ORIGIN', '*')

# GitHub 状态存储配置（全部从环境变量读取，不硬编码）
GITHUB_TOKEN = os.environ.get('GITHUB_TOKEN', '')
GITHUB_REPO = os.environ.get('GITHUB_REPO', 'forsaken30/zjut-kaoyan-pack')
GITHUB_BRANCH = os.environ.get('GITHUB_BRANCH', 'main')
STATE_FILE = 'state.json'

# 北京时区
BEIJING_TZ = timezone(timedelta(hours=8))

# 简单内存限流
_login_attempts = {}

# ===== 会话令牌管理 =====
# 每个会话令牌对应一个用户信息
_sessions = {}
_SESSION_TTL = 86400  # 24小时


def create_session(username, role, acc_type):
    """为登录用户创建独立会话令牌"""
    token = secrets.token_urlsafe(32)
    _sessions[token] = {
        'username': username,
        'role': role,
        'type': acc_type,
        'exp': time.time() + _SESSION_TTL
    }
    return token


def verify_session(token):
    """验证会话令牌，返回用户信息或None"""
    if not token:
        return None
    sess = _sessions.get(token)
    if not sess:
        return None
    if time.time() > sess['exp']:
        del _sessions[token]
        return None
    return sess


# ===== 动态每日密钥生成（替代静态daily_keys.json）=====
def get_today_daily_key():
    """根据 SECRET_SEED + 日期 动态生成当日密钥，永不过期"""
    today = get_today_str()
    # 用 SHA-256 派生确定性的密钥和盐值
    key_raw = SECRET_SEED + '|key|' + today
    salt_raw = SECRET_SEED + '|salt|' + today
    key_bytes = hashlib.sha256(key_raw.encode('utf-8')).digest()
    salt = hashlib.sha256(salt_raw.encode('utf-8')).hexdigest()[:16]
    return {
        'd': today,
        's': salt,
        'k': base64.b64encode(key_bytes).decode('ascii')
    }


# ===== GitHub 状态持久化 =====
_state_cache = None
_state_cache_time = 0
_state_cache_ttl = 300  # 5分钟缓存（从30秒延长，减少API调用）


def load_state():
    """从 GitHub 读取状态（带内存缓存，出错时降级到缓存）"""
    global _state_cache, _state_cache_time
    now = time.time()
    if _state_cache is not None and (now - _state_cache_time) < _state_cache_ttl:
        return _state_cache

    url = 'https://api.github.com/repos/{}/contents/{}?ref={}'.format(
        GITHUB_REPO, STATE_FILE, GITHUB_BRANCH)
    req = request.Request(url, headers={
        'Authorization': 'token ' + GITHUB_TOKEN,
        'Accept': 'application/vnd.github.v3+json',
        'User-Agent': 'SCF-Auth-Function'
    })
    try:
        with request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            content = base64.b64decode(data['content']).decode('utf-8')
            _state_cache = json.loads(content)
            _state_cache['sha'] = data.get('sha', '')
            _state_cache_time = now
            return _state_cache
    except error.HTTPError as e:
        if e.code == 404:
            # state.json 不存在，创建默认状态
            _state_cache = {'trial_activations': {}, 'account_overrides': {}, 'sha': None}
            _state_cache_time = now
            return _state_cache
    except Exception:
        pass
    # 出错时降级：使用内存中的缓存兜底
    if _state_cache is not None:
        return _state_cache
    _state_cache = {'trial_activations': {}, 'account_overrides': {}, 'sha': None}
    _state_cache_time = now
    return _state_cache


def save_state(new_state):
    """保存状态到 GitHub（带重试）"""
    global _state_cache, _state_cache_time
    # 强制清除缓存，获取最新 sha
    _state_cache = None
    _state_cache_time = 0
    current = load_state()
    sha = current.get('sha')

    # 准备内容（不包含 sha 字段）
    state_to_save = {
        'trial_activations': new_state.get('trial_activations', {}),
        'account_overrides': new_state.get('account_overrides', {})
    }
    content_bytes = json.dumps(state_to_save, ensure_ascii=False, indent=2).encode('utf-8')
    content_b64 = base64.b64encode(content_bytes).decode('ascii')

    url = 'https://api.github.com/repos/{}/contents/{}'.format(GITHUB_REPO, STATE_FILE)
    payload = {
        'message': 'Update state at {}'.format(datetime.now(BEIJING_TZ).isoformat()),
        'content': content_b64,
        'branch': GITHUB_BRANCH
    }
    if sha:
        payload['sha'] = sha

    data = json.dumps(payload).encode('utf-8')
    req = request.Request(url, data=data, method='PUT', headers={
        'Authorization': 'token ' + GITHUB_TOKEN,
        'Accept': 'application/vnd.github.v3+json',
        'User-Agent': 'SCF-Auth-Function',
        'Content-Type': 'application/json'
    })
    # 重试3次
    for attempt in range(3):
        try:
            with request.urlopen(req, timeout=15) as resp:
                resp_data = json.loads(resp.read().decode('utf-8'))
                new_state['sha'] = resp_data['content']['sha']
                _state_cache = new_state
                _state_cache_time = time.time()
                return True
        except error.HTTPError as e:
            if e.code == 409 and attempt < 2:
                # sha 冲突，重新获取
                _state_cache = None
                _state_cache_time = 0
                current = load_state()
                sha = current.get('sha')
                payload['sha'] = sha
                data = json.dumps(payload).encode('utf-8')
                req = request.Request(url, data=data, method='PUT', headers={
                    'Authorization': 'token ' + GITHUB_TOKEN,
                    'Accept': 'application/vnd.github.v3+json',
                    'User-Agent': 'SCF-Auth-Function',
                    'Content-Type': 'application/json'
                })
                continue
            return False
        except Exception:
            if attempt < 2:
                time.sleep(1)
                continue
            return False
    return False


# 前端使用的 SECRET_SEED（用于兼容前端生成的密码哈希）
FRONTEND_SECRET_SEED = 'ZJUT_MaterialSci_2026_DecisionPack_Secret_v2'

def hash_password(password, salt, secret=None):
    """SHA-256 + 盐值 + 1000轮迭代，兼容前端和后端密钥"""
    seed = secret or SECRET_SEED
    h = hashlib.sha256((salt + ':' + password + ':' + seed).encode('utf-8')).hexdigest()
    for i in range(1000):
        h = hashlib.sha256((h + ':' + salt + ':' + str(i)).encode('utf-8')).hexdigest()
    return 's2_' + h


def get_today_str():
    now = datetime.now(BEIJING_TZ)
    return '{}-{}-{}'.format(now.year, now.month, now.day)


def compute_daily_code():
    raw = SECRET_SEED + '|daily|' + get_today_str()
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()[:8]


def check_rate_limit(ip):
    now = time.time()
    if ip not in _login_attempts:
        _login_attempts[ip] = []
    _login_attempts[ip] = [t for t in _login_attempts[ip] if now - t < 60]
    if len(_login_attempts[ip]) >= 10:
        return False
    _login_attempts[ip].append(now)
    return True


def verify_account(username, password):
    """验证账号密码，检查状态/过期/试用"""
    try:
        accounts = json.loads(ACCOUNTS_JSON)
    except Exception:
        return None, '服务端配置错误'

    username = (username or '').strip().lower()
    state = load_state()

    for acc in accounts:
        if acc.get('username', '').lower() == username:
            # 检查账号状态（优先用 state 中的覆盖值）
            overrides = state.get('account_overrides', {})
            acc_status = overrides.get(username, acc.get('status', 'active'))
            if acc_status != 'active':
                return None, '账号已停用'

            # 检查过期
            expiry = acc.get('expiry')
            if expiry:
                try:
                    exp_date = datetime.strptime(str(expiry)[:10], '%Y-%m-%d')
                    if datetime.now() > exp_date:
                        return None, '账号已过期'
                except Exception:
                    pass

            # 试用账号：检查是否已过期（密码验证前）
            acc_type = acc.get('type', 'normal')
            if acc_type == 'trial':
                trial_hours = acc.get('trialHours', 0)
                trial_acts = state.get('trial_activations', {})
                activated_at = trial_acts.get(username)
                if activated_at:
                    exp_time = activated_at + trial_hours * 3600
                    if time.time() > exp_time:
                        # 试用已过期，清除激活记录，允许重新激活
                        del trial_acts[username]
                        state['trial_activations'] = trial_acts
                        save_state(state)

            # 验证密码（先尝试后端 SECRET_SEED，再尝试前端 SECRET_SEED 兼容）
            stored_hash = acc.get('passHash', '')
            salt = acc.get('salt', '')
            computed_hash = hash_password(password, salt)
            # 如果后端密钥不匹配，尝试前端密钥
            if not hmac.compare_digest(computed_hash, stored_hash):
                computed_hash_fe = hash_password(password, salt, FRONTEND_SECRET_SEED)
                if hmac.compare_digest(computed_hash_fe, stored_hash):
                    computed_hash = computed_hash_fe

            if hmac.compare_digest(computed_hash, stored_hash):
                # 密码验证成功后，如果是试用账号且未激活，则激活
                if acc_type == 'trial':
                    state = load_state()
                    trial_acts = state.get('trial_activations', {})
                    activated_at = trial_acts.get(username)
                    if not activated_at:
                        activated_at = time.time()
                        trial_acts[username] = activated_at
                        state['trial_activations'] = trial_acts
                        save_state(state)

                safe_acc = {
                    'username': acc['username'],
                    'role': acc.get('role', 'subscriber'),
                    'type': acc_type,
                    'trialHours': acc.get('trialHours'),
                    'expiry': expiry,
                    'status': acc_status,
                    'salt': acc.get('salt', ''),
                    'encryptedKey': acc.get('encryptedKey', '')
                }
                # 试用账号返回激活状态
                if acc_type == 'trial':
                    if activated_at:
                        safe_acc['activatedAt'] = datetime.fromtimestamp(activated_at, BEIJING_TZ).isoformat()
                        trial_hours = acc.get('trialHours', 0)
                        remaining = (activated_at + trial_hours * 3600) - time.time()
                        if remaining > 0:
                            safe_acc['trialStatus'] = 'active'
                            safe_acc['trialRemaining'] = int(remaining)
                        else:
                            safe_acc['trialStatus'] = 'expired'
                    else:
                        safe_acc['trialStatus'] = 'not_activated'
                return safe_acc, None
            else:
                return None, '密码错误(调试: stored=%s... salt=%s computed_sc=%s... computed_fe=%s...)' % (
                    stored_hash[:20], salt, computed_hash[:20],
                    hash_password(password, salt, FRONTEND_SECRET_SEED)[:20])

    return None, '账号不存在'


def get_accounts_summary():
    """获取账号列表摘要（master 可见）"""
    try:
        accounts = json.loads(ACCOUNTS_JSON)
    except Exception:
        return []

    state = load_state()
    overrides = state.get('account_overrides', {})
    trial_acts = state.get('trial_activations', {})

    summary = []
    for acc in accounts:
        username_lower = (acc.get('username') or '').lower()
        item = {
            'username': acc.get('username'),
            'role': acc.get('role', 'subscriber'),
            'type': acc.get('type', 'normal'),
            'expiry': acc.get('expiry'),
            'status': overrides.get(username_lower, acc.get('status', 'active')),
            'trialHours': acc.get('trialHours'),
            'activatedAt': None
        }

        if item['type'] == 'trial':
            activated = trial_acts.get(username_lower)
            if activated:
                item['activatedAt'] = datetime.fromtimestamp(activated, BEIJING_TZ).isoformat()
                trial_hours = acc.get('trialHours', 0)
                exp_time = activated + trial_hours * 3600
                remaining = exp_time - time.time()
                if remaining > 0:
                    item['trialStatus'] = 'active'
                    item['trialRemaining'] = int(remaining)
                else:
                    item['trialStatus'] = 'expired'
            else:
                item['trialStatus'] = 'not_activated'

        summary.append(item)

    return summary


def deactivate_account(username):
    """停用账号"""
    global _state_cache, _state_cache_time
    _state_cache = None
    _state_cache_time = 0
    state = load_state()
    overrides = state.get('account_overrides', {})
    username_lower = (username or '').strip().lower()
    overrides[username_lower] = 'inactive'
    state['account_overrides'] = overrides
    _state_cache = None
    _state_cache_time = 0
    return save_state(state)


def activate_account(username):
    """启用账号"""
    global _state_cache, _state_cache_time
    _state_cache = None
    _state_cache_time = 0
    state = load_state()
    overrides = state.get('account_overrides', {})
    username_lower = (username or '').strip().lower()
    if username_lower in overrides:
        del overrides[username_lower]
    state['account_overrides'] = overrides
    _state_cache = None
    _state_cache_time = 0
    return save_state(state)


def refresh_trial(username):
    """刷新试用账号（清除激活时间）"""
    global _state_cache, _state_cache_time
    _state_cache = None
    _state_cache_time = 0
    state = load_state()
    trial_acts = state.get('trial_activations', {})
    username_lower = (username or '').strip().lower()
    try:
        accounts = json.loads(ACCOUNTS_JSON)
        is_trial = any(
            a.get('username', '').lower() == username_lower and a.get('type') == 'trial'
            for a in accounts
        )
    except Exception:
        is_trial = True
    if not is_trial:
        return False
    if username_lower in trial_acts:
        del trial_acts[username_lower]
    state['trial_activations'] = trial_acts
    _state_cache = None
    _state_cache_time = 0
    return save_state(state)


def get_cors_origin(event):
    """根据请求Origin动态返回允许的CORS域名，支持多个域名"""
    req_headers = event.get('headers', {}) or {}
    origin = req_headers.get('origin') or req_headers.get('Origin') or ''
    # 允许的域名列表（从ALLOWED_ORIGIN解析，支持逗号分隔多个域名）
    allowed = [o.strip() for o in ALLOWED_ORIGIN.split(',')]
    if origin and origin in allowed:
        return origin
    # 如果ALLOWED_ORIGIN为*，允许所有
    if ALLOWED_ORIGIN == '*':
        return origin or '*'
    # 默认返回第一个允许的域名
    return allowed[0] if allowed else '*'


def main_handler(event, context):
    """SCF 主函数入口"""
    cors_origin = get_cors_origin(event)
    headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': cors_origin,
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    }

    http_method = event.get('httpMethod', 'POST')
    if http_method == 'OPTIONS':
        return {'statusCode': 200, 'headers': headers, 'body': ''}

    request_context = event.get('requestContext', {})
    source_ip = request_context.get('sourceIp', 'unknown')

    if not check_rate_limit(source_ip):
        return {
            'statusCode': 429,
            'headers': headers,
            'body': json.dumps({'error': '请求过于频繁，请稍后再试'}, ensure_ascii=False)
        }

    try:
        body_str = event.get('body', '{}')
        if event.get('isBase64Encoded'):
            body_str = base64.b64decode(body_str).decode('utf-8')
        body = json.loads(body_str)
    except Exception:
        return {
            'statusCode': 400,
            'headers': headers,
            'body': json.dumps({'error': '请求格式错误'}, ensure_ascii=False)
        }

    username = body.get('username', '')
    password = body.get('password', '')
    login_type = body.get('type', 'sub')
    action = body.get('action', 'login')

    # ===== 管理操作（需要 ADMIN_TOKEN，不再用 MASTER_KEY）=====
    if action in ('list_accounts', 'refresh_trial', 'deactivate_account', 'activate_account'):
        admin_token = body.get('adminToken', '') or body.get('token', '')
        if not admin_token or admin_token != ADMIN_TOKEN:
            return {
                'statusCode': 403,
                'headers': headers,
                'body': json.dumps({'error': '无管理权限'}, ensure_ascii=False)
            }

        if action == 'list_accounts':
            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps({'accounts': get_accounts_summary()}, ensure_ascii=False)
            }

        if action == 'deactivate_account':
            if deactivate_account(username):
                return {
                    'statusCode': 200,
                    'headers': headers,
                    'body': json.dumps({'ok': True, 'message': '账号已停用: ' + username}, ensure_ascii=False)
                }
            else:
                return {
                    'statusCode': 500,
                    'headers': headers,
                    'body': json.dumps({'error': '停用失败'}, ensure_ascii=False)
                }

        if action == 'activate_account':
            if activate_account(username):
                return {
                    'statusCode': 200,
                    'headers': headers,
                    'body': json.dumps({'ok': True, 'message': '账号已启用: ' + username}, ensure_ascii=False)
                }
            else:
                return {
                    'statusCode': 500,
                    'headers': headers,
                    'body': json.dumps({'error': '启用失败'}, ensure_ascii=False)
                }

        if action == 'refresh_trial':
            if refresh_trial(username):
                return {
                    'statusCode': 200,
                    'headers': headers,
                    'body': json.dumps({'ok': True, 'message': '试用账号已刷新: ' + username}, ensure_ascii=False)
                }
            else:
                return {
                    'statusCode': 400,
                    'headers': headers,
                    'body': json.dumps({'error': '未找到该试用账号'}, ensure_ascii=False)
                }

    # ===== 访客登录（每日动态密码）=====
    if login_type == 'daily':
        daily_code = compute_daily_code()
        if hmac.compare_digest(str(password), daily_code):
            daily_key = get_today_daily_key()
            session_token = create_session('visitor', 'visitor', 'daily')
            response_body = {
                'ok': True,
                'role': 'visitor',
                'username': 'visitor',
                'type': 'daily',
                'exp': int(time.time()) + 86400,
                'salt': daily_key.get('s', ''),
                'encryptedKey': daily_key.get('k', ''),
                'token': session_token  # 返回会话令牌，不是MASTER_KEY
            }
            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps(response_body, ensure_ascii=False)
            }
        else:
            return {
                'statusCode': 401,
                'headers': headers,
                'body': json.dumps({'error': '动态密码错误'}, ensure_ascii=False)
            }

    # ===== 订阅登录 =====
    acc, err = verify_account(username, password)
    if acc:
        session_token = create_session(
            acc.get('username', ''),
            acc.get('role', 'subscriber'),
            acc.get('type', 'normal')
        )
        response_body = {
            'ok': True,
            'role': acc.get('role', 'subscriber'),
            'username': acc.get('username', ''),
            'type': acc.get('type', 'normal'),
            'exp': int(time.time()) + 86400,
            'salt': acc.get('salt', ''),
            'encryptedKey': acc.get('encryptedKey', ''),
            'token': session_token  # 返回会话令牌，不是MASTER_KEY
        }

        # 仅master登录时返回 adminToken（用于管理操作）
        if acc.get('role') == 'master':
            response_body['adminToken'] = ADMIN_TOKEN
            response_body['accounts'] = get_accounts_summary()
            response_body['dailyCode'] = compute_daily_code()

        # 试用账号返回激活状态信息
        if acc.get('type') == 'trial':
            if acc.get('activatedAt'):
                response_body['activatedAt'] = acc['activatedAt']
            if acc.get('trialStatus'):
                response_body['trialStatus'] = acc['trialStatus']
            if acc.get('trialRemaining') is not None:
                response_body['trialRemaining'] = acc['trialRemaining']
            response_body['trialHours'] = acc.get('trialHours', 0)

        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps(response_body, ensure_ascii=False)
        }
    else:
        return {
            'statusCode': 401,
            'headers': headers,
            'body': json.dumps({'error': err or '认证失败'}, ensure_ascii=False)
        }
