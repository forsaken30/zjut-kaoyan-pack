# -*- coding: utf8 -*-
"""
浙工大材料学院考研决策包 - 认证云函数
腾讯云 SCF (Serverless Cloud Function) + Function URL 触发

环境变量:
  MASTER_KEY     - base64编码的32字节主密钥
  ACCOUNTS_JSON  - JSON字符串，账号列表（含密码哈希）
  SECRET_SEED    - 密钥种子
  ALLOWED_ORIGIN - 允许的前端域名（CORS）

状态持久化: 通过 GitHub API 读写 state.json，实现试用激活和账号停用的持久化
"""

import json
import hashlib
import hmac
import os
import time
import base64
from datetime import datetime, timezone, timedelta
from urllib import request, error

# ===== 从环境变量读取配置 =====
MASTER_KEY = os.environ.get('MASTER_KEY', '')
ACCOUNTS_JSON = os.environ.get('ACCOUNTS_JSON', '[]')
SECRET_SEED = os.environ.get('SECRET_SEED', '')
ALLOWED_ORIGIN = os.environ.get('ALLOWED_ORIGIN', '*')

# GitHub 状态存储配置
GITHUB_TOKEN = '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'
GITHUB_REPO = 'forsaken30/zjut-kaoyan-pack'
GITHUB_BRANCH = 'main'
STATE_FILE = 'state.json'

# 从本地文件读取每日密钥
_daily_keys_data = None
def _load_daily_keys():
    global _daily_keys_data
    if _daily_keys_data is not None:
        return _daily_keys_data
    env_val = os.environ.get('DAILY_KEYS_JSON', '')
    if env_val:
        try:
            _daily_keys_data = json.loads(env_val)
            return _daily_keys_data
        except Exception:
            pass
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        file_path = os.path.join(script_dir, 'daily_keys.json')
        with open(file_path, 'r', encoding='utf-8') as f:
            _daily_keys_data = json.load(f)
    except Exception:
        _daily_keys_data = []
    return _daily_keys_data

# 北京时区
BEIJING_TZ = timezone(timedelta(hours=8))

# 简单内存限流
_login_attempts = {}

# ===== GitHub 状态持久化 =====
_state_cache = None
_state_cache_time = 0
_state_cache_ttl = 30  # 30秒缓存


def load_state():
    """从 GitHub 读取状态（带内存缓存）"""
    global _state_cache, _state_cache_time
    now = time.time()
    if _state_cache is not None and (now - _state_cache_time) < _state_cache_ttl:
        return _state_cache

    url = 'https://api.github.com/repos/{}/contents/{}?ref={}'.format(
        GITHUB_REPO, STATE_FILE, GITHUB_BRANCH)
    req = request.Request(url, headers={
        'Authorization': 'token ' + GITHUB_TOKEN,
        'Accept': 'application/vnd.github.v3+json',
        'User-Agent': 'SCF-Auth-Function'
    })
    try:
        with request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            content = base64.b64decode(data['content']).decode('utf-8')
            _state_cache = json.loads(content)
            _state_cache['sha'] = data.get('sha', '')
            _state_cache_time = now
            return _state_cache
    except error.HTTPError as e:
        if e.code == 404:
            # state.json 不存在，创建默认状态
            _state_cache = {'trial_activations': {}, 'account_overrides': {}, 'sha': None}
            _state_cache_time = now
            return _state_cache
    except Exception:
        pass
    # 出错时使用内存中的缓存或默认值
    if _state_cache is not None:
        return _state_cache
    _state_cache = {'trial_activations': {}, 'account_overrides': {}, 'sha': None}
    _state_cache_time = now
    return _state_cache


def save_state(new_state):
    """保存状态到 GitHub"""
    global _state_cache, _state_cache_time
    # 获取当前 sha（用于更新）
    current = load_state()
    sha = current.get('sha')

    # 准备内容（不包含 sha 字段）
    state_to_save = {
        'trial_activations': new_state.get('trial_activations', {}),
        'account_overrides': new_state.get('account_overrides', {})
    }
    content_bytes = json.dumps(state_to_save, ensure_ascii=False, indent=2).encode('utf-8')
    content_b64 = base64.b64encode(content_bytes).decode('ascii')

    url = 'https://api.github.com/repos/{}/contents/{}'.format(GITHUB_REPO, STATE_FILE)
    payload = {
        'message': 'Update state at {}'.format(datetime.now(BEIJING_TZ).isoformat()),
        'content': content_b64,
        'branch': GITHUB_BRANCH
    }
    if sha:
        payload['sha'] = sha

    data = json.dumps(payload).encode('utf-8')
    req = request.Request(url, data=data, method='PUT', headers={
        'Authorization': 'token ' + GITHUB_TOKEN,
        'Accept': 'application/vnd.github.v3+json',
        'User-Agent': 'SCF-Auth-Function',
        'Content-Type': 'application/json'
    })
    try:
        with request.urlopen(req, timeout=15) as resp:
            resp_data = json.loads(resp.read().decode('utf-8'))
            new_state['sha'] = resp_data['content']['sha']
            _state_cache = new_state
            _state_cache_time = time.time()
            return True
    except Exception:
        return False


def hash_password(password, salt):
    """SHA-256 + 盐值 + 1000轮迭代"""
    h = hashlib.sha256((salt + ':' + password + ':' + SECRET_SEED).encode('utf-8')).hexdigest()
    for i in range(1000):
        h = hashlib.sha256((h + ':' + salt + ':' + str(i)).encode('utf-8')).hexdigest()
    return 's2_' + h


def get_today_str():
    now = datetime.now(BEIJING_TZ)
    return '{}-{}-{}'.format(now.year, now.month, now.day)


def compute_daily_code():
    raw = SECRET_SEED + '|daily|' + get_today_str()
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()[:8]


def get_today_daily_key():
    daily_keys = _load_daily_keys()
    if not daily_keys:
        return None
    today_str = get_today_str()
    for dk in daily_keys:
        if dk.get('d') == today_str:
            return dk
    return None


def check_rate_limit(ip):
    now = time.time()
    if ip not in _login_attempts:
        _login_attempts[ip] = []
    _login_attempts[ip] = [t for t in _login_attempts[ip] if now - t < 60]
    if len(_login_attempts[ip]) >= 10:
        return False
    _login_attempts[ip].append(now)
    return True


def verify_account(username, password):
    """验证账号密码，检查状态/过期/试用"""
    try:
        accounts = json.loads(ACCOUNTS_JSON)
    except Exception:
        return None, '服务端配置错误'

    username = (username or '').strip().lower()
    state = load_state()

    for acc in accounts:
        if acc.get('username', '').lower() == username:
            # 检查账号状态（优先用 state 中的覆盖值）
            overrides = state.get('account_overrides', {})
            acc_status = overrides.get(username, acc.get('status', 'active'))
            if acc_status != 'active':
                return None, '账号已停用'

            # 检查过期
            expiry = acc.get('expiry')
            if expiry:
                try:
                    exp_date = datetime.strptime(str(expiry)[:10], '%Y-%m-%d')
                    if datetime.now() > exp_date:
                        return None, '账号已过期'
                except Exception:
                    pass

            # 试用账号：检查是否已过期（密码验证前）
            acc_type = acc.get('type', 'normal')
            if acc_type == 'trial':
                trial_hours = acc.get('trialHours', 0)
                trial_acts = state.get('trial_activations', {})
                activated_at = trial_acts.get(username)
                if activated_at:
                    exp_time = activated_at + trial_hours * 3600
                    if time.time() > exp_time:
                        return None, '试用已过期'

            # 验证密码
            stored_hash = acc.get('passHash', '')
            salt = acc.get('salt', '')
            computed_hash = hash_password(password, salt)

            if hmac.compare_digest(computed_hash, stored_hash):
                # 密码验证成功后，如果是试用账号且未激活，则激活
                if acc_type == 'trial':
                    # 重新加载状态（可能在上面的过期检查后被其他请求修改）
                    state = load_state()
                    trial_acts = state.get('trial_activations', {})
                    activated_at = trial_acts.get(username)
                    if not activated_at:
                        # 首次激活 - 持久化到 GitHub
                        activated_at = time.time()
                        trial_acts[username] = activated_at
                        state['trial_activations'] = trial_acts
                        save_state(state)

                safe_acc = {
                    'username': acc['username'],
                    'role': acc.get('role', 'subscriber'),
                    'type': acc_type,
                    'trialHours': acc.get('trialHours'),
                    'expiry': expiry,
                    'status': acc_status,
                    'salt': acc.get('salt', ''),
                    'encryptedKey': acc.get('encryptedKey', '')
                }
                # 试用账号返回激活状态
                if acc_type == 'trial':
                    if activated_at:
                        # 转换为 ISO 字符串（前端需要 new Date() 解析）
                        safe_acc['activatedAt'] = datetime.fromtimestamp(activated_at, BEIJING_TZ).isoformat()
                        trial_hours = acc.get('trialHours', 0)
                        remaining = (activated_at + trial_hours * 3600) - time.time()
                        if remaining > 0:
                            safe_acc['trialStatus'] = 'active'
                            safe_acc['trialRemaining'] = int(remaining)
                        else:
                            safe_acc['trialStatus'] = 'expired'
                    else:
                        safe_acc['trialStatus'] = 'not_activated'
                return safe_acc, None
            else:
                return None, '密码错误'

    return None, '账号不存在'


def get_accounts_summary():
    """获取账号列表摘要（master 可见）"""
    try:
        accounts = json.loads(ACCOUNTS_JSON)
    except Exception:
        return []

    state = load_state()
    overrides = state.get('account_overrides', {})
    trial_acts = state.get('trial_activations', {})

    summary = []
    for acc in accounts:
        username_lower = (acc.get('username') or '').lower()
        item = {
            'username': acc.get('username'),
            'role': acc.get('role', 'subscriber'),
            'type': acc.get('type', 'normal'),
            'expiry': acc.get('expiry'),
            'status': overrides.get(username_lower, acc.get('status', 'active')),
            'trialHours': acc.get('trialHours'),
            'activatedAt': None
        }

        if item['type'] == 'trial':
            activated = trial_acts.get(username_lower)
            if activated:
                item['activatedAt'] = datetime.fromtimestamp(activated, BEIJING_TZ).isoformat()
                trial_hours = acc.get('trialHours', 0)
                exp_time = activated + trial_hours * 3600
                remaining = exp_time - time.time()
                if remaining > 0:
                    item['trialStatus'] = 'active'
                    item['trialRemaining'] = int(remaining)
                else:
                    item['trialStatus'] = 'expired'
            else:
                item['trialStatus'] = 'not_activated'

        summary.append(item)

    return summary


def deactivate_account(username):
    """停用账号"""
    global _state_cache, _state_cache_time
    _state_cache = None
    _state_cache_time = 0
    state = load_state()
    overrides = state.get('account_overrides', {})
    username_lower = (username or '').strip().lower()
    overrides[username_lower] = 'inactive'
    state['account_overrides'] = overrides
    _state_cache = None
    _state_cache_time = 0
    return save_state(state)


def activate_account(username):
    """启用账号"""
    global _state_cache, _state_cache_time
    _state_cache = None
    _state_cache_time = 0
    state = load_state()
    overrides = state.get('account_overrides', {})
    username_lower = (username or '').strip().lower()
    if username_lower in overrides:
        del overrides[username_lower]
    state['account_overrides'] = overrides
    _state_cache = None
    _state_cache_time = 0
    return save_state(state)


def refresh_trial(username):
    """刷新试用账号（清除激活时间）"""
    # 强制清除缓存，从 GitHub 重新读取
    global _state_cache, _state_cache_time
    _state_cache = None
    _state_cache_time = 0
    state = load_state()
    trial_acts = state.get('trial_activations', {})
    username_lower = (username or '').strip().lower()
    # 检查是否是试用账号
    try:
        accounts = json.loads(ACCOUNTS_JSON)
        is_trial = any(
            a.get('username', '').lower() == username_lower and a.get('type') == 'trial'
            for a in accounts
        )
    except Exception:
        is_trial = True
    if not is_trial:
        return False
    # 删除激活记录（而非设为 None）
    if username_lower in trial_acts:
        del trial_acts[username_lower]
    state['trial_activations'] = trial_acts
    # 保存前再次清除缓存确保获取最新 sha
    _state_cache = None
    _state_cache_time = 0
    return save_state(state)


def main_handler(event, context):
    """SCF 主函数入口"""
    headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': ALLOWED_ORIGIN,
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    }

    http_method = event.get('httpMethod', 'POST')
    if http_method == 'OPTIONS':
        return {'statusCode': 200, 'headers': headers, 'body': ''}

    request_context = event.get('requestContext', {})
    source_ip = request_context.get('sourceIp', 'unknown')

    if not check_rate_limit(source_ip):
        return {
            'statusCode': 429,
            'headers': headers,
            'body': json.dumps({'error': '请求过于频繁，请稍后再试'}, ensure_ascii=False)
        }

    try:
        body_str = event.get('body', '{}')
        if event.get('isBase64Encoded'):
            body_str = base64.b64decode(body_str).decode('utf-8')
        body = json.loads(body_str)
    except Exception:
        return {
            'statusCode': 400,
            'headers': headers,
            'body': json.dumps({'error': '请求格式错误'}, ensure_ascii=False)
        }

    username = body.get('username', '')
    password = body.get('password', '')
    login_type = body.get('type', 'sub')
    action = body.get('action', 'login')

    # ===== 管理操作（需要 master token）=====
    if action in ('list_accounts', 'refresh_trial', 'deactivate_account', 'activate_account'):
        token = body.get('token', '')
        if token != MASTER_KEY:
            return {
                'statusCode': 403,
                'headers': headers,
                'body': json.dumps({'error': '无权限'}, ensure_ascii=False)
            }

        if action == 'list_accounts':
            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps({'accounts': get_accounts_summary()}, ensure_ascii=False)
            }

        if action == 'deactivate_account':
            if deactivate_account(username):
                return {
                    'statusCode': 200,
                    'headers': headers,
                    'body': json.dumps({'ok': True, 'message': '账号已停用: ' + username}, ensure_ascii=False)
                }
            else:
                return {
                    'statusCode': 500,
                    'headers': headers,
                    'body': json.dumps({'error': '停用失败'}, ensure_ascii=False)
                }

        if action == 'activate_account':
            if activate_account(username):
                return {
                    'statusCode': 200,
                    'headers': headers,
                    'body': json.dumps({'ok': True, 'message': '账号已启用: ' + username}, ensure_ascii=False)
                }
            else:
                return {
                    'statusCode': 500,
                    'headers': headers,
                    'body': json.dumps({'error': '启用失败'}, ensure_ascii=False)
                }

        if action == 'refresh_trial':
            if refresh_trial(username):
                return {
                    'statusCode': 200,
                    'headers': headers,
                    'body': json.dumps({'ok': True, 'message': '试用账号已刷新: ' + username}, ensure_ascii=False)
                }
            else:
                return {
                    'statusCode': 400,
                    'headers': headers,
                    'body': json.dumps({'error': '未找到该试用账号'}, ensure_ascii=False)
                }

    # ===== 访客登录（每日动态密码）=====
    if login_type == 'daily':
        daily_code = compute_daily_code()
        if hmac.compare_digest(str(password), daily_code):
            daily_key = get_today_daily_key()
            response_body = {
                'ok': True,
                'role': 'visitor',
                'username': 'visitor',
                'type': 'daily',
                'exp': int(time.time()) + 86400,
                'salt': daily_key.get('s', '') if daily_key else '',
                'encryptedKey': daily_key.get('k', '') if daily_key else '',
                'token': MASTER_KEY
            }
            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps(response_body, ensure_ascii=False)
            }
        else:
            return {
                'statusCode': 401,
                'headers': headers,
                'body': json.dumps({'error': '动态密码错误'}, ensure_ascii=False)
            }

    # ===== 订阅登录 =====
    acc, err = verify_account(username, password)
    if acc:
        response_body = {
            'ok': True,
            'role': acc.get('role', 'subscriber'),
            'username': acc.get('username', ''),
            'type': acc.get('type', 'normal'),
            'exp': int(time.time()) + 86400,
            'salt': acc.get('salt', ''),
            'encryptedKey': acc.get('encryptedKey', ''),
            'token': MASTER_KEY
        }

        # 试用账号返回激活状态信息
        if acc.get('type') == 'trial':
            if acc.get('activatedAt'):
                response_body['activatedAt'] = acc['activatedAt']
            if acc.get('trialStatus'):
                response_body['trialStatus'] = acc['trialStatus']
            if acc.get('trialRemaining') is not None:
                response_body['trialRemaining'] = acc['trialRemaining']
            response_body['trialHours'] = acc.get('trialHours', 0)

        if acc.get('role') == 'master':
            response_body['accounts'] = get_accounts_summary()
            response_body['dailyCode'] = compute_daily_code()

        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps(response_body, ensure_ascii=False)
        }
    else:
        return {
            'statusCode': 401,
            'headers': headers,
            'body': json.dumps({'error': err or '认证失败'}, ensure_ascii=False)
        }
